import os
import random
import uuid
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from flask import Flask, render_template, request, redirect, url_for, session

from seeding import random_seeding, standard_seeding, balanced_seeding
from simulation import simulate_tournament
from comparison import run_comparison

app=Flask(__name__)
app.secret_key='zavrsni-rad-sports-tournament-generator'
MAX_PLAYERS=32
SEEDING_ALGORITHMS={
    'random':('Nasumični raspored (Random Seeding)', random_seeding),
    'standard':('Standardni raspored (Standard Seeding)', standard_seeding),
    'balanced':('Uravnoteženi raspored (Balanced Seeding)', balanced_seeding),
}

_SAMPLE_NAMES=[
    'Ivan Horvat', 'Marko Kovač', 'Ana Babić', 'Petra Marić', 'Luka Jurić',
    'Ivana Novak', 'Tomislav Vuković', 'Nikola Knežević', 'Matej Perić',
    'Karlo Matić', 'Filip Radić', 'Iva Šimić', 'Dora Božić', 'Josip Grgić',
    'Antonio Tomić', 'Lea Pavić', 'Mia Blažević', 'David Jukić', 'Ema Barišić',
    'Roko Dujmović', 'Vito Delač', 'Klara Rukavina', 'Lovro Šarić', 'Zvonimir Katić',
    'Petar Vidović', 'Domagoj Kraljević', 'Bruno Jurković', 'Marina Lovrić',
    'Tin Rogić', 'Vjeran Šimunović', 'Damir Lučić', 'Stela Bagarić',
]

def _generate_random_players(n):
    names=random.sample(_SAMPLE_NAMES, min(n, len(_SAMPLE_NAMES)))
    while len(names)<n:
        names.append(f'Igrač {len(names)+1}')
    return [
        {'id': uuid.uuid4().hex[:8], 'name': names[i], 'elo': random.randint(1400, 2400)} 
        for i in range(n)
        ]

def _next_power_of_two_at_most(n, minimum=4, maximum=32):
    n=max(minimum, min(maximum, n))
    power=minimum
    while power*2<=n:
        power*=2
    return power

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/players', methods=['GET', 'POST'])
def players():
    players_list=session.get('players', [])
    last_num_players=session.get('last_num_players', 8)
    error=None

    if request.method=='POST':
        action=request.form.get('action')

        if action=='generate':
            n=_next_power_of_two_at_most(int(request.form.get('num_players', 8)))
            players_list=_generate_random_players(n)
            session['players']=players_list
            session['last_num_players']=n
            last_num_players=n

        elif action=='add_manual':
            if len(players_list)>=MAX_PLAYERS:
                error=f'Dosegnut je maksimalan broj sudionika ({MAX_PLAYERS}). Uklonite nekoga da dodate novog.'
            else:
                name=request.form.get('name', '').strip()
                elo_raw=request.form.get('elo', '').strip()
                if name and elo_raw.isdigit():
                    new_player={'id': uuid.uuid4().hex[:8], 'name':name, 'elo': int(elo_raw)}
                    players_list=players_list+[new_player]
                    session['players']=players_list
                else:
                    error='Unesite ispravno ime i Elo rating (cijeli broj).'

        elif action=='remove':
            remove_id=request.form.get('player_id')
            players_list=[p for p in players_list if p.get('id')!=remove_id]
            session['players']=players_list

        elif action=='clear':
            players_list=[]
            session['players']=players_list

        elif action=='continue':
            algorithm=request.form.get('algorithm', 'standard')
            n=len(players_list)
            if n<4 or (n & (n-1))!=0:
                error='Broj sudionika mora biti potencija broja 2 (4, 8, 16 ili 32).'
            else:
                session['algorithm']=algorithm
                return redirect(url_for('bracket'))

    return render_template('players.html', players=players_list, error=error, last_num_players=last_num_players, max_players=MAX_PLAYERS)

@app.route('/bracket')
def bracket():
    players_list=session.get('players', [])
    algorithm_key=session.get('algorithm', 'standard')

    if not players_list:
        return redirect(url_for('players'))

    algorithm_name, seeding_func=SEEDING_ALGORITHMS[algorithm_key]
    seeded=seeding_func(players_list)
    session['seeded']=seeded

    return render_template('bracket.html', seeded=seeded, algorithm_name=algorithm_name)

@app.route('/simulate')
def simulate():
    seeded=session.get('seeded')
    algorithm_key=session.get('algorithm', 'standard')

    if not seeded:
        return redirect(url_for('players'))

    algorithm_name=SEEDING_ALGORITHMS[algorithm_key][0]
    result=simulate_tournament(seeded)

    return render_template('results.html', result=result, algorithm_name=algorithm_name)

@app.route('/compare', methods=['GET', 'POST'])
def compare():
    if request.method=='POST':
        players_list=session.get('players', [])
        if len(players_list)<4:
            players_list=_generate_random_players(8)
            session['players']=players_list

        num_sim=max(500, min(5000, int(request.form.get('num_simulations', 500))))
        stats=run_comparison(players_list, num_simulations=num_sim)
        _create_comparison_chart(stats)

        return render_template(
            'compare.html',
            has_results=True,
            stats=stats,
            num_sim=num_sim,
            num_players=len(players_list),
        )

    return render_template('compare.html', has_results=False, num_sim=500)

def _create_comparison_chart(stats):
    charts_dir=os.path.join('static', 'charts')
    os.makedirs(charts_dir, exist_ok=True)
    filepath=os.path.join(charts_dir, 'comparison_chart.png')

    names=list(stats.keys())
    top_seed_pct=[stats[n]['top_seed_win_pct'] for n in names]
    avg_elo=[stats[n]['avg_finalist_elo'] for n in names]
    colors=['#0B3D91', '#3B6FD6', '#7FA8F0']

    fig, axes=plt.subplots(1, 2, figsize=(10, 4.2))

    axes[0].bar(names, top_seed_pct, color=colors)
    axes[0].set_title('Pobjede najjačeg nositelja (%)')
    axes[0].set_label('%')
    axes[0].tick_params(axis='x', rotation=15)

    axes[1].bar(names, avg_elo, color=colors)
    axes[1].set_title('Prosječni Elo finalista')
    axes[1].set_ylabel('Elo')
    axes[1].tick_params(axis='x', rotation=15)

    fig.tight_layout()
    fig.savefig(filepath, dpi=110)
    plt.close(fig)


if __name__=='__main__':
    app.run(debug=True)