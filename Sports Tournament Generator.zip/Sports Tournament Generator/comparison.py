import time

from seeding import random_seeding, standard_seeding, balanced_seeding
from simulation import simulate_tournament

ALGORITHMS={
    'Random Seeding': random_seeding,
    'Standard Seeding': standard_seeding,
    'Balanced Seeding': balanced_seeding,
}

def run_comparison(players, num_simulations=500):
    if len(players)<2:
        raise ValueError('Potrebno je najmanje 2 sudionika za usporedbu algoritama.')

    top_player=max(players, key=lambda p: p['elo'])
    results={}

    for name, seeding_func in ALGORITHMS.items():
        start=time.time()
        top_seed_wins=0
        finalist_elo_sum=0.0

        for _ in range(num_simulations):
            seeded=seeding_func(players)
            outcome=simulate_tournament(seeded)

            if outcome['champion']['name']==top_player['name']:
                top_seed_wins+=1

            final_match=outcome['rounds'][-1]['matches'][0]
            finalist_elo_sum+=(final_match['player1']['elo']+final_match['player2']['elo'])/2

        elapsed=time.time()-start

        results[name]={
            'top_seed_win_pct': round(top_seed_wins/num_simulations*100, 2),
            'avg_finalist_elo': round(finalist_elo_sum/num_simulations, 1),
            'execution_time_ms': round((elapsed/num_simulations)*1000, 3),
            'total_time_s': round(elapsed, 3),
        }

    return results