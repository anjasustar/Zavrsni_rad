import random

def _sorted_by_elo(players):
    return sorted(players, key=lambda p: p['elo'], reverse=True)

def random_seeding(players):
    shuffled=players[:]
    random.shuffle(shuffled)
    return shuffled

def _bracket_order(n):
    if n==1:
        return [1]
    prev=_bracket_order(n//2)
    order=[]
    for s in prev:
        order.append(s)
        order.append(n+1-s)
    return order

def standard_seeding(players):
    ranked=_sorted_by_elo(players)
    n=len(ranked)
    order=_bracket_order(n)
    return [ranked[seed-1] for seed in order]

def balanced_seeding(players):
    ranked=_sorted_by_elo(players)
    n=len(ranked)

    num_groups=4 if n>=4 else n
    group_size=n//num_groups

    groups=[ranked[i*group_size:(i+1)*group_size] for i in range(num_groups)]

    remainder=ranked[num_groups*group_size:]
    if remainder:
        groups[-1].extend(remainder)

    for group in groups:
        random.shuffle(group)

    bracket=[]
    max_len=max(len(group) for group in groups)
    for i in range(max_len):
        for group in groups:
            if i < len(group):
                bracket.append(group[i])

    return bracket
