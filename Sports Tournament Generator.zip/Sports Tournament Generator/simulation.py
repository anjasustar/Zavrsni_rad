import math
import random

from elo import expected_score

_ROUND_NAMES_FROM_END=['Finale', 'Polufinale', 'Četvrtfinale', 'Osmina finala', '1/16 finala']

def _round_name(round_num, total_rounds):
    idx_from_end=total_rounds-round_num
    if idx_from_end<len(_ROUND_NAMES_FROM_END):
        return _ROUND_NAMES_FROM_END[idx_from_end]
    return f'{round_num}. kolo'

def simulate_tournament(seeded_players):
    if len(seeded_players)<2:
        raise ValueError('Za simulaciju turnira potrebno je najmanje 2 sudionika.')

    total_rounds=int(math.log2(len(seeded_players)))
    current_round=seeded_players[:]
    rounds=[]
    round_num=1

    while len(current_round)>1:
        matches=[]
        next_round=[]

        for i in range(0, len(current_round), 2):
            player1=current_round[i]
            player2=current_round[i+1]

            prob1=expected_score(player1['elo'], player2['elo'])
            winner=player1 if random.random()<prob1 else player2

            matches.append({
                'player1':player1,
                'player2':player2,
                'prob1':round(prob1*100, 1),
                'prob2':round((1-prob1)*100, 1),
                'winner':winner,
            })
            next_round.append(winner)

        rounds.append({
            'round_num':round_num,
            'round_name':_round_name(round_num, total_rounds),
            'matches':matches,
        })

        current_round=next_round
        round_num+=1

    champion=current_round[0]
    top_seed=max(seeded_players, key=lambda p: p['elo'])

    return{
        'rounds':rounds,
        'champion':champion,
        'top_seed':top_seed,
        'upset':champion['name'] !=top_seed['name'],
    }